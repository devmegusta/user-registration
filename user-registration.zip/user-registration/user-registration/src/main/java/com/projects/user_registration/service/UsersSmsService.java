package com.projects.user_registration.service;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.stereotype.Service;

@Service
public class UsersSmsService {
    private static final String ACCOUNT_SID = "";
    private static final String AUTH_TOKEN = "";
    private static final String TWILIO_PHONE_NUMBER = "";

    public UsersSmsService(){
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    public void sendSms(String message, String destinyNumber){
        Message message1 = Message.creator(
                new PhoneNumber(destinyNumber),
                new PhoneNumber(TWILIO_PHONE_NUMBER),
                message
        ).create();

        System.out.println("SMS enivado" + message1.getSid());
    }

}

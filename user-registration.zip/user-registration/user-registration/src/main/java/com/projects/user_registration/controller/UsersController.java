package com.projects.user_registration.controller;
import com.projects.user_registration.model.Users;
import com.projects.user_registration.repository.UsersRepository;
import com.projects.user_registration.service.UsersSmsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UsersController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private UsersSmsService usersSmsService;

    @PostMapping
    public ResponseEntity<Users> registerUser(@RequestBody Users user){
        Users newUser = usersRepository.save(user);
        usersSmsService.sendSms("Novo usuário cadastrado: " + user.getName(), user.getPhoneNumber());
        return ResponseEntity.ok(newUser);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Users> updateUser(@PathVariable Long id, @RequestBody Users users) {
        if (!usersRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        users.setId(id);
        Users userUpdated = usersRepository.save(users);
        usersSmsService.sendSms("Usuário atualizado com sucesso: " + users.getName(), users.getPhoneNumber());
        return ResponseEntity.ok(userUpdated);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id){
        Optional<Users> users = usersRepository.findById(id);
        if (users.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        usersRepository.deleteById(id);
        usersSmsService.sendSms("Usuário deletado com sucesso: " + users.get().getName(), users.get().getPhoneNumber());
        return ResponseEntity.noContent().build();
    }
}

